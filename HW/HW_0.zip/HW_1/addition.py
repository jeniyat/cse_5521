"""
To run this script, type

  python addition.py
"""

def add(a, b):
    "Return the sum of a and b"
    "*** YOUR CODE HERE ***"
    return 0
